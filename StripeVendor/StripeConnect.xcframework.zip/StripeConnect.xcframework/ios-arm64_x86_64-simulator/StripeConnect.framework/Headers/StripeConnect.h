//
//  StripeConnect.h
//  StripeConnect
//
//  Created by Chris Mays on 7/31/24.
//

#import <Foundation/Foundation.h>

//! Project version number for StripeConnect.
FOUNDATION_EXPORT double StripeConnectVersionNumber;

//! Project version string for StripeConnect.
FOUNDATION_EXPORT const unsigned char StripeConnectVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StripeConnect/PublicHeader.h>
