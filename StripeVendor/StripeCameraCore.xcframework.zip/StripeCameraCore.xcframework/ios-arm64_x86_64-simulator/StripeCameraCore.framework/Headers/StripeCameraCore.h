//
//  StripeCameraCore.h
//  StripeCameraCore
//
//  Created by Mel Ludowise on 11/15/21.
//

#import <Foundation/Foundation.h>

//! Project version number for StripeCameraCore.
FOUNDATION_EXPORT double StripeCameraCoreVersionNumber;

//! Project version string for StripeCameraCore.
FOUNDATION_EXPORT const unsigned char StripeCameraCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StripeCameraCore/PublicHeader.h>


